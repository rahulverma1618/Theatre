const express = require('express');
const expressWs = require('express-ws');
const fs = require('fs');
const path = require("path");

const app = express();
const wsApp = expressWs(app)

app.use(express.urlencoded({ extended: true }));
app.use(express.json())
app.use(express.static(path.join(__dirname, "static")))

const port = 8000;

app.get("/theater", (req, res) => {
  res.sendFile(path.join(__dirname, "pages/index.html"));
})

app.get("/theater/getMyIp", (req, res) => {
  res.send({ "ip": req.ip })
})

app.get("/new", (req, res) => {
  page = `
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Page title</title>
</head>
<body>
you here to clear localStorage<br>
<script>
    window.localStorage.clear()
    document.body.innerText+="pov that all cleared local storage : "+JSON.stringify(window.localStorage.getItem("members"))
</script>   
</body>
</html>
    `
  res.send(page)
})





app.get('/theater/video', (req, res) => {
  const videoPath = path.join(__dirname, '/video/Java OOPs in One Shot _ Object Oriented Programming _ Java Language _ Placement Course.mp4');

  const filesize = fs.statSync(videoPath).size;

  const [start, end] = req.headers.range.replace("bytes=", "").split("-").map((elt) => elt == "" || elt == undefined ? filesize - 1 : parseInt(elt, 10));

  const chunksize = (end - start) + 1;

  res.status(206).header(
    {
      'Content-Range': `bytes ${start}-${end}/${filesize}`,
      'Accept-Ranges': 'bytes',
      'Content-Length': chunksize,
      'Content-Type': 'video/mp4'
    }
  );

  const file = fs.createReadStream(videoPath, { start, end })

  file.pipe(res)

})




//connecting clients

const clients = new Set();
const addresses = new Set();

app.ws("/data", (ws, req) => {
  var ip = req.connection.remoteAddress;
  clients.add(ws);

  //command to activate all users so they can start video and to reset all values to default if a new user joins the room
  addrs = Array.from(clients).map((client) => client._socket._peername.address);
  sendAll(ws,clients,JSON.stringify({ status: "new user joined", statusCode: 200, "allClients": Array.from(addresses), "joinIp": ws._socket._peername.address, "activeClients": addrs }))

  ws.send(JSON.stringify({ status: "your Ip", statusCode: 96, selfIp: ws._socket._peername.address }))

  ws.on('message', async (data) => {
    data = JSON.parse(data.toString())
    //handle messages  
    if (data.sendType == "all") {
      sendAll(ws,clients,JSON.stringify(data))
    }
    else if (data.sendType == "allExceptMe") {
      sendAllExceptMe(ws,clients,JSON.stringify(data))
    }

    ws.on('close', () => {
      clients.delete(ws);
      addresses.add(ws._socket._peername.address);

      sendAll(ws,clients,JSON.stringify({ status: "user left theater", statusCode: 109, userIp: ws._socket._peername.address }))
    });
  })
})





// processing audio 
const audioClients = new Set();

app.ws("/audio", (ws, req) => {
  console.log("conected to mic")
  audioClients.add(ws);

  ws.on("message", (data) => {
    ws.send(JSON.stringify(data));
    // sendAll(ws,audioClients,data)
  })

  ws.on("close", () => {
    console.log("discnoocted to mic")
    audioClients.delete(ws);
  })
})






// functions
function sendAll(ws,clients,data) {
  clients.forEach((client) => {
    if (client.readyState === ws.OPEN) {
      client.send(data);
    }
  })
}

function sendAllExceptMe(ws,clients,data) {
  clients.forEach((client) => {
    if (client != ws && client.readyState === ws.OPEN) {
      client.send(data);
    }
  })
}

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
