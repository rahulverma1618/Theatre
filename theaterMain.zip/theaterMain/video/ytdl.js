const ytdl = require('ytdl-core'); 
const fs = require('fs') 

let url = "https://youtu.be/nD_NDngrEl8";
     ytdl(url).pipe(fs.createWriteStream('video.mp4')); 