window.addEventListener("load", async () => {
    const playBtn = document.getElementById("playBtn");
    const fullScreen = document.getElementById("fullScreen");
    const controls = document.getElementById("controls");
    const membersDiv = document.getElementById("membersDiv");
    const mineMemberDiv = document.getElementById("mineMemberDiv");
    const hideBtn = document.getElementsByClassName("closeMemersBtn")[0];

    var isReadyBtnEventListenerCalled = false;
    var isPlatBtnEventListenerCalled = false;
    var isVideoPaused = 1;
    var isButtonClicked = 0;
    var myIp = await getMyIp();
    var readyMembers = new Set();
    var members = new Set();
    var allMembers = new Set();
    var iNeedOldTime = 0;
    var isSeeking = 0;
    var orignalSeek = 1;
    var isVoiceOf = 1;

    const globalUrl = `ws://${window.location.hostname}:${window.location.port}`;

    const video = document.getElementById("video");

    const dataSocket = new WebSocket(globalUrl + "/data");

    dataSocket.addEventListener("open", async (event) => {
        console.log("Connected to server data");
        await sendMsg(
            JSON.stringify({
                status: "retrieve old time",
                statusCode: 98,
                sendType: "allExceptMe",
            })
        );
        // fetch  some data from all members
        dataSocket.send(JSON.stringify({
            status: "fetch ready members",
            statusCode: 199,
            sendType: "allExceptMe"
        }));
    });

    dataSocket.addEventListener("close", (event) => {
        console.log("Disconnected from server data");
    });

    dataSocket.addEventListener("error", (error) => {
        console.error("WebSocket error data:", error);
    });

    dataSocket.addEventListener("message", (event) => {
        const message = event.data;
        data = event.data;
        activities(data);
    });

    async function activities(incomingData) {
        var data = JSON.parse(incomingData);




        //process handlers


        //create a ui to show mic and speaker state of all clients 
        //make a button to turn it on or off 

        //if the mic button is on then they can send audio bytes

        if (data.statusCode == 90) {
            //seekstart
            orignalSeek = 0;
            isSeeking = 1;
            seekTime = data.seekTo;
            video.currentTime = seekTime
        }
        else if (data.statusCode == 91) {
            //seekend
            setTimeout(() => {
                isSeeking = 0;
                orignalSeek = 1;
            }, 400);
        }
        else if (data.statusCode == 96) {
            myIp = data.selfIp;
        }
        else if (data.statusCode == 97) {
            //set incoming matched time at rejoin            
            if (iNeedOldTime) {
                time = data.time;
                video.currentTime = time;
            }
            iNeedOldTime = 0;
        } else if (data.statusCode == 98) {
            // help other to set accurate time
            time = video.currentTime;
            await sendMsg(
                JSON.stringify({
                    status: "send current time indeed",
                    statusCode: 97,
                    time: time,
                    sendType: "allExceptMe",
                })
            );
        }
        else if (data.statusCode == 100) {
        }
        else if (data.statusCode == 109) {
            // user left 
            readyMembers.delete(data.userIp);
            members.delete(data.userIp)
            updateUiMembers();
            pauseVideo();
            showPopUp("", data.userIp + "left")
            enableDisablePlayBtn();
        }
        else if (data.statusCode == 198) {
            //load ready members
            readyMembers = new Set([...data.data]);
            readyMembers.forEach((ip) => {
                readyUi(ip);
            });
        }
        else if (data.statusCode == 199) {
            dataSocket.send(JSON.stringify({
                status: "give ready members",
                statusCode: 198,
                data: Array.from(readyMembers),
                sendType: "allExceptMe"
            }))
        }
        else if (data.statusCode == 200) {
            //check for join
            members = new Set([...data.activeClients]);
            allMembers = new Set([...data.allClients])
            iNeedOldTime = 1;

            showPopUp("", `${data.joinIp}  joined`);
            updateUiMembers();
            pauseVideo()
            enableDisablePlayBtn()
        }
        else if (data.statusCode == 301) {
            readyMembers.delete(data.ip);
            unReadyUi(data.ip);
            pauseVideo();
            enableDisablePlayBtn();
        }
        else if (data.statusCode == 300) {
            readyMembers.add(data.ip);
            //make ui ready          
            readyUi(data.ip);
            enableDisablePlayBtn();
        }
        else if (data.statusCode == 206) {
            playVideo();
        }
        else if (data.statusCode == 205) {
            pauseVideo();
        }
        else if (data.statusCode == 201) {
            mineTime = video.currentTime;
            gap = Math.max(mineTime, data.time) - Math.min(mineTime, data.time);
            if (gap > 0.5) {
                lagger = Math.min(mineTime, data.time);
                await sendMsg(
                    JSON.stringify({
                        status: "changing time",
                        statusCode: 202,
                        changeTime: lagger,
                        sendType: "all",
                    })
                );
            }
        }
        else if (data.statusCode == 202 && data.changeTime > 0) {
            video.currentTime = data.changeTime;
        }
    }

    // video play event listener to block playing video if all are not ready
    video.addEventListener("play", async () => {
        if (readyMembers.size != members.size) {
            video.pause();
        }
    })

    playBtn.addEventListener("click", async () => {
        if (isVideoPaused) {
            await sendMsg(JSON.stringify({
                status: "play", statusCode: 206,
                ip: myIp,
                sendType: "all",
            }));
        } else {
            await sendMsg(JSON.stringify({
                status: "pause",
                statusCode: 205,
                ip: myIp,
                sendType: "all",
            }));
        }
    })


    //create your activity
    readyPlayBtn = document.querySelector("#readyPlayBtn")
    readyPlayBtn.addEventListener("click", async (event) => {
        if (!readyMembers.has(myIp)) {
            await sendMsg(JSON.stringify({
                status: "im  ready", statusCode: 300,
                ip: myIp,
                sendType: "all",
            }));

        } else {
            await sendMsg(JSON.stringify({
                status: "im unready",
                statusCode: 301,
                ip: myIp,
                sendType: "all",
            }));
        }
    })



    setInterval(async () => {
        if (!isVideoPaused && !iNeedOldTime && !isSeeking) {
            time = await getCrntTime();
            await sendMsg(
                JSON.stringify({
                    status: "fetching time",
                    statusCode: 201,
                    time: time,
                    sendType: "allExceptMe",
                })
            );
        }
    }, 100);

    function enableDisablePlayBtn() {
        if (readyMembers.size == members.size) {
            playBtn.disabled = false;
            playBtn.style.backgroundColor = "red";
        }
        else {
            playBtn.disabled = true;
            playBtn.style.backgroundColor = "white";
        }
    }

    function getCrntTime() {
        return new Promise((resolve, reject) => {
            resolve(video.currentTime);
        });
    }

    function playVideo() {
        if (isVideoPaused) {
            video.play();
            isVideoPaused = 0;
        }
    }

    function pauseVideo() {
        if (!isVideoPaused) {
            video.pause();
            isVideoPaused = 1;
        }
    }

    async function sendMsg(msg) {
        return new Promise((resolve, reject) => {
            resolve(dataSocket.send(msg));
        })
    }

    function setAllDefault() {
        // readyMembers.clear();
    }

    async function getMyIp() {
        return new Promise((resolve, reject) => {
            fetch("/theater/getMyIp", {
                headers: {
                    "Content-Type": "application/json"
                }
            })
                .then(res => res.json())
                .then(res => {
                    resolve(res.ip);
                })

        })
    }





    //video controls

    //full screen
    fullScreen.addEventListener("click", (event) => {
        if (document.fullscreenElement || document.webkitFullscreenElement) {
            document.exitFullscreen();
            video.style.cssText = `
      width:100%;
      height:100%;            
      margin :2%;
      padding:0;
      overflow: visible;
      `;
            document.documentElement.style.overflow = "visible";
            controls.style.width = "100%";
        } else {
            document.documentElement.requestFullscreen();
            video.style.cssText = `
      height:100vh; 
      width:100%;         
      margin :0;
      padding:0;
      overflow:hidden;
      `;
            document.documentElement.style.overflow = "hidden";
            controls.style.width = "100%";
        }
    });

    //seeking 
    video.addEventListener("seeking", () => {
        if (orignalSeek && !isSeeking) {
            isSeeking = 1;
            //pauseVideo();
            sendMsg(JSON.stringify({
                status: "seeking",
                statusCode: 90,
                seekTo: video.currentTime,
                sendType: "allExceptMe"
            }))
        }
    });
    video.addEventListener("seeked", () => {
        isSeeking = 0;
        //playVideo();
        sendMsg(JSON.stringify({
            status: "seeking off",
            statusCode: 91,
            seekTo: video.currentTime,
            sendType: "allExceptMe"
        }))
    });

    // some common fucntion
    //btn clicked
    function clicked(id) {
        elt = document.getElementById(id)
        elt.classList.add('clicked')
        setTimeout(() => {
            elt.classList.remove("clicked")
        }, 300);
    }

    function showPopUp(title, msgBody) {

        if (msgBody.replace("joined", "").trim() == myIp && msgBody.includes("joined")) {
            msgBody = "You Joined"
        }
        else if (msgBody.replace("left", "").trim() == myIp && msgBody.includes("left")) {
            msgBody = "You left"
        }


        const popup = document.createElement("div");
        popup.classList.add("popup");

        const ps1 = document.createElement("p");
        ps1.className = "title"
        ps1.textContent = title;

        const ps2 = document.createElement("p");
        ps2.className = "body"
        ps2.textContent = msgBody;

        popup.appendChild(ps1);
        popup.appendChild(ps2);

        document.getElementById("popupCont").appendChild(popup);
        setTimeout(() => {
            document.getElementById("popupCont").removeChild(popup);
        }, 6000)
    }




    //update ui of memebers
    function updateUiMembers() {
        membersDiv.innerHTML = "";
        if (members.size < 2) {
            membersDiv.style.display = "none"
            hideBtn.style.display = "none"
        }
        else {
            membersDiv.style.display = "block"
            hideBtn.style.display = "block"
        }
        members.forEach((memberId) => {
            if (memberId != myIp) {
                const memberDiv = document.createElement('div');
                memberDiv.classList.add('memberDiv', "others");
                memberDiv.id = "memberDiv" + ipToId(memberId);

                // Create the username div
                const userDiv = document.createElement('div');
                userDiv.classList.add('username', "allCenter");
                userDiv.textContent = memberId;

                // Create the mic div
                const micDiv = document.createElement('div');
                micDiv.classList.add('mic', "allCenter");

                // Create the speaker div
                const speakerDiv = document.createElement('div');
                speakerDiv.classList.add('speaker', "allCenter");

                // Create the readyPlay div
                const readyPlayDiv = document.createElement('div');
                readyPlayDiv.classList.add('readyPlay', "allCenter");
                readyPlayDiv.textContent = "Not Ready"

                // Append the mic, speaker, and readyPlay divs to the member div
                memberDiv.appendChild(userDiv);
                memberDiv.appendChild(micDiv);
                memberDiv.appendChild(speakerDiv);
                memberDiv.appendChild(readyPlayDiv);

                membersDiv.appendChild(memberDiv);
            }
            else if (mineMemberDiv) {
                if (mineMemberDiv.id == "mineMemberDiv") {
                    mineMemberDiv.id = "memberDiv" + ipToId(myIp);
                    mineMemberDiv.firstElementChild.innerText = "You"
                }
            }
        })
    }



    function readyUi(ip) {
        elt = document.querySelector(`#memberDiv${ipToId(ip)} .readyPlay`)
        // elt.style.backgroundColor = "yellow"
        elt.style.opacity = "1"
        elt.innerText = "Ready"
    }

    function unReadyUi(ip) {
        elt = document.querySelector(`#memberDiv${ipToId(ip)} .readyPlay`)
        // elt.style.backgroundColor = "white"
        elt.style.opacity = "0.5"
        elt.innerText = "Not Ready"
    }

    function ipToId(ip) {
        return `${ip.replaceAll(":", "").replaceAll(".", "-")}`
    }
    // fold memmers cont

    hideBtn.addEventListener("click", (event) => {
        if (hideBtn.getAttribute("stat") == "0") {
            membersDiv.classList.remove("showDiv");
            membersDiv.classList.add("hideDiv");
            hideBtn.setAttribute("stat", "1");
            hideBtn.innerText = "Show";
        }
        else {
            // membersDiv.classList.remove("hideDiv");
            membersDiv.classList.add("showDiv");
            hideBtn.setAttribute("stat", "0");
            hideBtn.innerText = "Hide";
        }
    })



















    // mic and speaker

    const mic = document.querySelector("#mineMemberDiv .mic");
    const speaker = document.querySelector("#mineMemberDiv .speaker");
    let audioSocket;
    let microphone;
    let audioContext;

    mic.addEventListener("click", async () => {
        if (!microphone) {
            audioSocket = new WebSocket(globalUrl + "/audio")
            audioContext = new (window.AudioContext || window.webkitAudioContext)();

            await audioSocketOpen()
            // handle call
            navigator.mediaDevices.getUserMedia({ audio: true })
                .then((stream) => {
                    microphone = audioContext.createMediaStreamSource(stream);

                    const scriptProcessor = audioContext.createScriptProcessor(1024, 1, 1);
                    scriptProcessor.onaudioprocess = (e) => {
                        const voiceData = e.inputBuffer.getChannelData(0);
                        const uint8Array = new Uint8Array(voiceData);
                        // sendVoiceData(voiceData.buffer);
                        handleIncomingVoiceData(voiceData.buffer)
                    };
                    microphone.connect(scriptProcessor);
                    scriptProcessor.connect(audioContext.destination);
                })
                .catch((error) => {
                    console.error('Error accessing microphone:', error);
                });
        }
        else {
            console.log("started")
            await audioSocketClose();
            console.log("ended")
        }
    })

    function sendVoiceData(data) {
        if (audioSocket && audioSocket.readyState === WebSocket.OPEN) {
            audioSocket.send(data);
        }
    }

    async function audioSocketOpen() {
        return new Promise((resolve, reject) => {
            resolve(
                audioSocket.addEventListener("open", (event) => {
                    // console.log("connected from server audio");
                }),

                audioSocket.addEventListener("close", (event) => {
                    // console.log("Disconnected from server audio");
                }),

                audioSocket.addEventListener("error", (error) => {
                    console.error("WebSocket error audio:", error);
                }),

                audioSocket.addEventListener("message", (event) => {
                    const message = event.data;
                    // handleIncomingVoiceData(message);
                })
            )
        })
    }

    async function audioSocketClose() {
        return new Promise((resolve, reject) => {
            resolve(
                audioSocket.close(), audioSocket.removeEventListener("open", () => {}),
                audioSocket.removeEventListener("close", () => { }),
                audioSocket.removeEventListener("message", () => { }),
                audioSocket.removeEventListener("error", () => { }),
                microphone.disconnect(),
                microphone.mediaStream.getTracks().forEach(track => track.stop()),
                microphone = null
            )
        })
    }

    async function handleIncomingVoiceData(audio) {

        const float32Array = new Float32Array(audio);
        // console.log(float32Array)
        const audioContext = new (window.AudioContext || window.webkitAudioContext)();
        const audioBuffer = audioContext.createBuffer(1, float32Array.length, audioContext.sampleRate);
        const audioData = audioBuffer.getChannelData(0);
        audioData.set(float32Array);
        const source = audioContext.createBufferSource();
        source.buffer = audioBuffer;
        source.connect(audioContext.destination);
        source.start();

    }

    speaker.addEventListener("click", () => {
        // isVoiceOf = 0
        // then incoming bytes of audio are allowed to play
    })

    //load ends here
});


/*
200 user joined
100 not all ready
300 im ready
206 playing
205 pause
201 fetching time
202 changing time
109 user left
99 get members
*/






ese kyu reply kra tumhe koi frk ni pda kya merko loss hua ??